-----------------------------------------------------------------
Corporations Canada Open Data
-----------------------------------------------------------------

This archive contains Corporations Canada's open data. 

An updated archive is provided free of charge to interested parties at

http://www.ic.gc.ca/app/scr/cc/CorporationsCanada/download/OPEN_DATA_SPLIT.zip

The archive should contain the following files:

openDataReadme.txt 		- This file
corpcan-open.xsd		- Open data schema
corpcan-codes.xsd		- Type codes schema
codes.xml				- Type codes XML
OPEN_DATA_X.xml 		- Complete xml extraction split into 25MB chunks 

 



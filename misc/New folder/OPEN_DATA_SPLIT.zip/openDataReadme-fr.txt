-----------------------------------------------------------------
Donn�es Ouvertes de Corporations Canada
-----------------------------------------------------------------

Cette archive contient les donn�es ouvertes de Corporations Canada. 

Les donn�es les plus courantes sont disponibles �

http://www.ic.gc.ca/app/scr/cc/CorporationsCanada/download/OPEN_DATA_SPLIT.zip

Cette archive devrait contenir les fichiers suivants:

openDataReadme-fr.txt   - Ce ficher
openDataReadme-en.txt   - Ce ficher, en anglais
corpcan-open.xsd        - Sch�ma des donn�es ouvertes
corpcan-codes.xsd       - Sch�ma des codes de type
codes.xml               - XML des codes de type
OPEN_DATA_X.xml         - XML complet extraction divis�e en fragments de 25MB  

 


